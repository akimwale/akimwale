from django.shortcuts import render, redirect
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.contrib.auth.models import auth, Group, User
from django.contrib import messages
from telusko_app.decorators import unauthorized, allowed_users, admin_only
from telusko_app.views import *
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from .models import *
from .forms import *
from .filter import order_search
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.core.cache import cache
import datetime
from django.utils import timezone
import json
import re
import os
from django.views.decorators.csrf import csrf_exempt
import logging
from django.core.mail import send_mail
from django.contrib.auth.decorators import user_passes_test
from django.utils import timezone
from django.http import HttpResponse
from django.forms import modelform_factory

logger = logging.getLogger(__name__)

@user_passes_test(unauthorized, login_url='/')

# Create your views here.

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.info(request, 'invalid credentials')
            return redirect('login')
    else:
        return render(request, 'login.html')

def register(request):
    form = CreateUser()
    if request.method == 'POST':
        form = CreateUser(request.POST)
        if form.is_valid():
            user= form.save()
            username = form.cleaned_data.get('username')

            # group = Group.objects.get(name='customer')
            # user.groups.add(group)
            # Customer.objects.create(
            #     user = user,
            # )
            messages.success(request, 'Account was created for ' +  username)
            # Create a notification for successful booking
            

            return redirect('/login')

    context = {'form':form}
    return render(request, 'signup.html', context)


def unauthorized(user):
    return not user.is_authenticated


def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            Notification.objects.create(
                user=user,
                message=f"You have been successfully logged in at {timezone.now().strftime('%Y-%m-%d %H:%M:%S')}."
            )
            return redirect('/')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    return redirect('/login')

@csrf_exempt
def predefined_messages(request):
    if request.method == 'GET':
        messages = FAQ.objects.values_list('question', flat=True)
        return JsonResponse({'messages': list(messages)})
    return JsonResponse({'error': 'Invalid request method'}, status=400)

@csrf_exempt
def chatbot(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            question = data.get('question', '')
            faq = FAQ.objects.filter(question__icontains=question).first()
            response = {'answer': faq.answer if faq else 'Sorry, I don\'t have an answer for that question, but you can talk directly to customer supprt on the home page.'}
            return JsonResponse(response)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=400)

def chatter(request):
    user_profile = Customer.objects.get(user=request.user)
    faqs = FAQ.objects.all()
    return render(request, 'chatbot.html', {'faqs': faqs, 'user_profile':user_profile})

@login_required(login_url='login')
def profile(request, pk):
    customer = get_object_or_404(Customer, id=pk)
    orders = customer.order_set.all()
    product = Product.objects.all()
    total_orders = orders.count()
    pending = orders.filter(status='Pending').count()
    completed = orders.filter(status='Completed').count()
    satisfied = orders.filter(status='Satisfied').count()
    unread_notifications_count = request.user.notifications.filter(read=False).count()
    
    search_term = request.GET.get('search', '')
    
    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES, instance=customer)
        if form.is_valid():
            form.save()
            
            # Create a notification for profile update
            Notification.objects.create(
                user=request.user,
                message="Your profile has been updated successfully."
            )
            
            return redirect('profile', pk=pk)
    else:
        form = CustomerForm(instance=customer)
    
    context = {
        'customer': customer, 
        'orders': orders, 
        'total': total_orders, 
        'pending': pending, 
        'completed': completed, 
        'satisfied': satisfied, 
        'form': form,
        'search_term': search_term,
        'unread_notifications_count': unread_notifications_count,
        'product':product
    }
    return render(request, 'profile.html', context)

@login_required
def notifications(request):
    user_notifications = request.user.notifications.all().order_by('-created_at')
    return render(request, 'notifications.html', {'notifications': user_notifications})

from django.http import HttpResponseRedirect
@login_required
def mark_as_read(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.read = True
    notification.save()
    return HttpResponseRedirect('/notifications/')

@login_required
def mark_as_unread(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.read = False
    notification.save()
    return JsonResponse({'status': 'success'})

@login_required
def delete_notification(request, notification_id):
    notification = get_object_or_404(Notification, id=notification_id, user=request.user)
    notification.delete()
    return JsonResponse({'status': 'success'})


def purchase_recovery_key(request):
    customer = Customer.objects.filter(user=request.user).first()
    if request.method == 'POST':
        form = RecoveryKeyRequestForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/digital')  # Redirect to a success page or handle accordingly
    else:
        form = RecoveryKeyRequestForm()

    return render(request, 'recovery.html', {'form': form, 'customer':customer})


def keys(request):
    keys = DigitalKey.objects.all()
    
    if request.user.is_authenticated:
        customer = Customer.objects.filter(user=request.user).first()
        if customer:
            return render(request, 'keys.html', {'keys': keys, 'customer': customer})
        else:
            return render(request, 'keys.html', {'keys': keys, 'error': 'No customer profile found.'})
    
    return render(request, 'keys.html', {'keys': keys})

def payment_page(request, key_id):
    if request.user.is_authenticated:
        customer = Customer.objects.filter(user=request.user).first()
        if customer:
            return render(request, 'payment_page.html', {'customer': customer})
        else:
            return render(request, 'payment_page.html', {'error': 'No customer profile found.'})
    try:
        key = get_object_or_404(DigitalKey, id=key_id)
    except DigitalKey.DoesNotExist:
        # Handle the case where the DigitalKey does not exist
        return render(request, 'error_page.html', {'error': 'Digital Key not found.'})

    if request.method == 'POST':
        form = PaymentForm(request.POST)
        if form.is_valid():
            # Handle payment processing
            return redirect('payment_success')
    else:
        form = PaymentForm(initial={'key': key})

    return render(request, 'payment_page.html', {'form': form, 'key': key})



def gift_card_payment(request):
    if request.user.is_authenticated:
        customer = Customer.objects.filter(user=request.user).first()
        if customer:
            return render(request, 'gift_card_page.html', {'customer': customer})
        else:
            return render(request, 'gift_card_page.html', {'error': 'No customer profile found.'})
    if request.method == 'POST':
        form = GiftCardPaymentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/')
    else:
        form = GiftCardPaymentForm()
    return render(request, 'gift_card_page.html', {'form': form})

def crypto_payment(request):
    if request.user.is_authenticated:
        customer = Customer.objects.filter(user=request.user).first()
        if customer:
            # Get the crypto wallet details, including network cost
            bitcoin_wallet = CryptoWallet.objects.filter(currency='bitcoin').first()
            usdt_wallet = CryptoWallet.objects.filter(currency='usdt').first()
            ethereum_wallet = CryptoWallet.objects.filter(currency='ethereum').first()
            
            # Prepare the context for rendering
            context = {
                'customer': customer,
                'bitcoin_address': bitcoin_wallet.address if bitcoin_wallet else None,
                'bitcoin_network': bitcoin_wallet.get_network_type_display() if bitcoin_wallet else None,
                'bitcoin_cost': bitcoin_wallet.network_cost if bitcoin_wallet else None,
                'usdt_address': usdt_wallet.address if usdt_wallet else None,
                'usdt_network': usdt_wallet.get_network_type_display() if usdt_wallet else None,
                'usdt_cost': usdt_wallet.network_cost if usdt_wallet else None,
                'ethereum_address': ethereum_wallet.address if ethereum_wallet else None,
                'ethereum_network': ethereum_wallet.get_network_type_display() if ethereum_wallet else None,
                'ethereum_cost': ethereum_wallet.network_cost if ethereum_wallet else None,
                'networks': CryptoWallet.objects.all(),
            }
            return render(request, 'crypto_page.html', context)
        else:
            return render(request, 'crypto_page.html', {'error': 'No customer profile found.'})

    # For non-authenticated users or if customer is not found
    return render(request, 'crypto_page.html', {'error': 'User is not authenticated or no customer profile found.'})


def transfer_redirect(request, method_name):
    redirect_url = PaymentMethodRedirect.objects.filter(method_name=method_name).first().redirect_url
    return redirect(redirect_url)


def mobile_bank(request):
    profiles = ProfileApp.objects.all()

    if request.user.is_authenticated:
        customer = Customer.objects.filter(user=request.user).first()

        if customer:
            return render(request, 'mobile_bank.html', {'customer': customer, 'profiles': profiles})
        else:
            return render(request, 'mobile_bank.html', {'error': 'No customer profile found.', 'profiles': profiles})

    return render(request, 'mobile_bank.html', {'profiles': profiles})

def get_social_apps(request, profile_id):
    profile = ProfileApp.objects.get(id=profile_id)
    social_apps = profile.social_apps.all()
    social_apps_data = [{
        'name': app.name,
        'image_url': app.image.url,
        'link': app.link
    } for app in social_apps]
    
    return JsonResponse({'social_apps': social_apps_data})

